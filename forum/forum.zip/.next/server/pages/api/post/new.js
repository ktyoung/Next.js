"use strict";
(() => {
var exports = {};
exports.id = 976;
exports.ids = [976,748];
exports.modules = {

/***/ 166:
/***/ ((module) => {

module.exports = require("@next-auth/mongodb-adapter");

/***/ }),

/***/ 67096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 38013:
/***/ ((module) => {

module.exports = require("mongodb");

/***/ }),

/***/ 73227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 47449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 47459:
/***/ ((module) => {

module.exports = require("next-auth/providers/github");

/***/ }),

/***/ 52496:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _util_database__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(29722);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(73227);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _auth_nextauth___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45884);



async function handler(request, response) {
    if (request.method == "POST") {
        // 현재 로그인한 유저 정보 (민감한 개인 정보는 유저가 직접 보내면 안 됨!)
        let session = await (0,next_auth__WEBPACK_IMPORTED_MODULE_1__.getServerSession)(request, response, _auth_nextauth___WEBPACK_IMPORTED_MODULE_2__.authOptions);
        console.log(session);
        if (session) {
            request.body.author = session.user.email;
            console.log(request.body);
        }
        // console.log(request.body); // 유저가 보낸 데이터(input에 입력한 데이터)
        // 예외처리: 제목을 작성하지 않았을 때
        if (request.body.title == "") {
            return response.status(500).json("제목을 작성하세요.");
        }
        // 예외처리: DB 에러
        // → try 블록 내부 코드에서 에러가 발생하면, catch 블록 내부의 코드를 실행함
        try {
            const db = (await _util_database__WEBPACK_IMPORTED_MODULE_0__/* .connectDB */ .u).db("forum");
            // DB에 document 발행하려면 → insertOne(데이터)
            let result = await db.collection("post").insertOne(request.body);
            // 응답과 동시에 페이지를 이동시키려면
            // → redirect(302, "/경로")
            return response.redirect(302, "/list");
        } catch (error) {}
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [884], () => (__webpack_exec__(52496)));
module.exports = __webpack_exports__;

})();