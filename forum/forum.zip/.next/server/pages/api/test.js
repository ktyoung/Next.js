"use strict";
(() => {
var exports = {};
exports.id = 318;
exports.ids = [318];
exports.modules = {

/***/ 51972:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
// 서버 기능 만들기
// root 폴더에 pages/api 폴더 생성
// → /api/test로 GET/POST/PUT/DELETE/PATCH 등 요청하면 이 파일의 코드를 실행함
function handler(request, response) {
    if (request.method == "POST") {
        return response.status(200).json("POST 요청됨");
    } else if (request.method == "GET") {
        return response.status(200).json("GET 요청됨");
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(51972));
module.exports = __webpack_exports__;

})();