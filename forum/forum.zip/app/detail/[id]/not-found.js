// 404 에러 페이지는 not-found.js

export default function NotFound() {
  return (
    <div>
      <h4>페이지 찾을 수 없음</h4>
    </div>
  );
}
